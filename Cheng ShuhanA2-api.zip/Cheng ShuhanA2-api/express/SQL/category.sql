INSERT INTO `category` (`CATEGORY_ID`, `NAME`) VALUES (1, 'Basic Needs Assistance');
INSERT INTO `category` (`CATEGORY_ID`, `NAME`) VALUES (2, 'Education');
INSERT INTO `category` (`CATEGORY_ID`, `NAME`) VALUES (3, 'Medical Assistance');
